package receiver;

import java.io.BufferedReader;


/**
 * @author stoffer
 * This is an interface for classes acting as a receiver
 * Classes impl this interface will talk to the main server
 */
public interface IReceiver {

	
	/**
	 * Method to send text to the server
	 * Should be non blocking, and return before text 
	 * is delivered to server
	 * @param text
	 */
	public void write(String text);
	
	/**
	 * This is getting text from the server.
	 * If there is data in the read buffer one single line is returned
	 * If no data is available, NULL is returned
	 * @return The string from the server or NULL
	 */
	public String readLine();
	
	/**
	 * Returns a handle to the input stream to read from
	 * @return
	 */
	public BufferedReader getReadStream();
	
}
