package receiver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.CharBuffer;

/**
 * This class will connect to the pseudoClient using a socket
 * connection
 * @author stoffer
 *
 */
public class SocketReceiver implements IReceiver {
	
	protected Socket socket = null;
	protected String host = "localhost";
	protected int port = 4321;
	protected PrintWriter out = null;
	protected BufferedReader in = null;
	
	
	/**
	 * Setup the connection
	 */
	public SocketReceiver() {
		try {
			this.socket = new Socket(this.host,this.port);
			this.in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			this.out = new PrintWriter(this.socket.getOutputStream());
		} catch (UnknownHostException e) {
			System.err.println("Unknown server hostname: "+this.host+" at port "+this.port);
			System.err.println(e.toString());
			//e.printStackTrace();
			System.exit(1);
		} catch (IOException e) {
			System.err.println("I/O error when trying to create connection to "+this.host+" on port: "+this.port);
			System.err.println(e.toString());
			System.exit(1);
		}
		System.out.println("Connected to server at: "+this.host);
	}
	
	@Override
	public void write(String text) {
//		System.out.println("<- "+text);
//        System.out.flush();
		this.out.print(text+"\n");
		this.out.flush();
	}

	@Override
	public String readLine() {
			String s = null;
			try {				
				s = this.in.readLine();
//                System.out.println("-> "+s);
//                System.out.flush();
			} catch (IOException e) {
				System.err.println("Could not read from socket connection!");
				System.err.println(e.toString());
				System.exit(1);
			}
			return s;
	}
	
	public BufferedReader getReadStream() {
		return this.in;
	}

}
