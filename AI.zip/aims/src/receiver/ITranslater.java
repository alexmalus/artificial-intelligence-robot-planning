package receiver;

public interface ITranslater {
	
	public String sendListOfActions();
	
	public Boolean[] getListOfReplies(String replies);
	
}
