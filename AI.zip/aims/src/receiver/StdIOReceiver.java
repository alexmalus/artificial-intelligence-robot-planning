/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package receiver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author stoffer
 */
public class StdIOReceiver implements IReceiver {
    
    BufferedReader reader;
    
    public StdIOReceiver() {
        this.reader = new BufferedReader(new InputStreamReader(System.in));
    }
    
    @Override
    public void write(String text) {
        System.out.println(text);
    }

    @Override
    public String readLine() {
        String s = null;
        try {
            s = this.reader.readLine();
        } catch (IOException ex) {
            Logger.getLogger(StdIOReceiver.class.getName()).log(Level.SEVERE, null, ex);
            System.exit(1);
        }
        return s;
    }

    @Override
    public BufferedReader getReadStream() {
        return this.reader;
    }
    
}
