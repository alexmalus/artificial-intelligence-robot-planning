package receiver;

import java.util.ArrayList;

public class Translater implements ITranslater{

	@Override
	public String sendListOfActions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean[] getListOfReplies(String replies) {
		ArrayList<Boolean> listOfReplies = new ArrayList<Boolean>();
		return null;
	}


}
