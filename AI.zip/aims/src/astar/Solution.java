package astar;

import java.util.List;

/**
 * Class that denotes a solution as returned by the A* implementation.
 * 
 * @author Jens Peter Trff & Thor Helms
 *
 * @param <A> Action
 * @param <S> State
 */
public class Solution<A, S extends Comparable<S>> {
	public S goalState;
	double cost;
	List<Node<A,S>> path;
	
	/**
	 * Constructor.
	 * @param path Path that solves the problem.
	 * @param cost Cost of solving the problem using the given path.
	 */
	public Solution(List<Node<A,S>> path, double cost, S s) {
		this.path = path;
		this.cost = cost;
		goalState = s;
	}
	
	public List<Node<A, S>> getPath() {
		return path;
	}
}
