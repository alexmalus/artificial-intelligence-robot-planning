package aims;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import aims.Task.TaskType;

public class LookForHelp {
	
	public static int getBlockingBox(Task task, Agent agent){
		int intMap[] = Level.realMap.clone();

		int agentId = agent.getId();
		int color = Level.getAgentColor(agentId);

		
		for (int i = 0; i < Level.realMap.length;i++) {
			int box = intMap[i];
			
			// remove boxes
			if (Level.isBox(box) && i != task.initBoxPosition){//Level.getBoxColor(box) != color) {
				intMap[i] = 0;
			}
		
			// Remove other agents
			int oAgent = intMap[i];
			if (Level.isAgent(oAgent) && Level.getAgentId(oAgent) != agentId) {
				intMap[i] = 0;
			}
		}

		Map map = new Map(intMap, new Map(intMap, null));

		Plan plan = agent.computePlan(task, new ArrayList<Plan>(), new ArrayList<Integer>(), map);
		
		if (plan == null)
			return -1;

		int position = agent.getIndexOnMap();
		ArrayList<Integer> places = new ArrayList<Integer>();
		places.add(position);
		for (Action action : plan) {
			position = Level.getPosFromPosInDirection(position,
					action.direction());
			boolean isBox = Level.isBox(Level.realMap[position]);
			boolean isGoal = position != task.initBoxPosition;
			if(isBox && isGoal )//&& agent.color != Level.getBoxColor(Level.realMap[position]))
					return position;
		}

		return -1;
	}
}
