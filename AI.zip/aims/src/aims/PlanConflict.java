/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package aims;

import java.util.ArrayList;

/**
 *
 * @author stoffer
 */
public class PlanConflict extends ArrayList<Plan> {
    protected int step;
    
    public PlanConflict(int step, Plan conflict1) {
        this.step = step;
        this.add(conflict1);
    }
    
    public PlanConflict(int step, Plan conflict1, Plan conflict2) {
        this.step = step;
        this.add(conflict1);
        this.add(conflict2);
        if (conflict1 == conflict2) 
            System.err.println("Uh, the plan are conflicting with itself - is this possible??");
    }
    
    @Override
    public String toString() {
        String str = "\n - Step "+this.step;
        if (this.size() == 1) {
            str += " in a plan collide: "+this.get(this.step).toString()+"\n";
        }
        else {
            str += " in "+this.size()+" plans collide:\n";
            for (Plan p: this) {
                str += "   - "+p.get(this.step).toString()+"\n";
            }
        }
        
        return str;
    }
}
