package aims;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**
 * This class will manage the initial assignment of tasks / goals to the agents
 * The intelligence behind the task distribution is implementation specific
 * In other words: At this time its unknown, we should make it better at some point.
 *  
 * @author kristoffer
 */
public class TaskDistribute {
	
	protected ArrayList<Agent> agents;
	protected ArrayList<Integer> goals;
    //HashMap assignedGoals;
	protected ArrayList<Integer> boxes;
	//protected ArrayList<Task> freeTasks;
    //protected ArrayList<Task> assignedTasks;
    //protected ArrayList<Task> completedTasks;
    protected ArrayList<Task> tasks;
	protected int[] realMap;
	protected Level level;
    protected HashMap<Integer,Integer> agentTrials;
	/**
	 * Initialize an object with a list of agents and goals/tasks
	 * this initialization will NOT assign any goals to agents. Call the assign() method for this.
	 * @param ag An array of available agents
	 * @param goals An array of the existing goals/tasks
	 * @param boxes An array of boxes in the map
	 */
	public TaskDistribute(ArrayList<Agent> ag, int[] realMap, Level level) {
		this.agents = ag;
		this.level = level;
        this.realMap = realMap;
        //this.freeTasks = new ArrayList<Task>();
        //this.assignedTasks = new ArrayList<Task>();
        //this.completedTasks = new ArrayList<Task>();
        this.tasks = new ArrayList<Task>();
        this.getGoalsAndBoxes();
        this.agentTrials = new HashMap<Integer,Integer>(this.agents.size());
	}
	
	protected void getGoalsAndBoxes() {
		this.goals = (ArrayList<Integer>) this.level.getGoals().clone();
		this.boxes = (ArrayList<Integer>) this.level.getBoxes().clone();
	}
	
	/**
	 * This method should assign tasks to all agents if possible. On exit, every
	 * agent should have a valid task assigned, and no plans should conflict.
	 * 
	 * This method should first check to see if any tasks can be distributed at
	 * all.
	 * 
	 * It should also calculate and possibly sort/prioritize/select tasks.
	 */
	public void assignTasks(boolean addNewTasks) {
		
		
		for (Agent a: this.agents) {
            Task at = a.getCurrentTask();
            //if (at != null && at.isCompleted())
            if (at != null && at.isCompleted())
                this.releaseTask(a);
        }
		
		ArrayList<Agent> freeAgents = new ArrayList<Agent>();
		for (Agent a : this.agents){
			if (!a.hasNext())
				freeAgents.add(a);
		}
		
		ArrayList<Task> freeTasks = this.getFreeTasks();
        
        //Get first task and query all available agents
        // for a plan for the task
        /*while (this.availableAgents())
            this.assignTask(this.freeTasks.get(0));*/
		
		//ArrayList<Task> appTasks = getUndependentTasks(freeTasks);
		ArrayList<Task> appTasks = this.getUndependentTasks(freeTasks);
        
        //Array holding all bids
        ArrayList<TaskBid> bids = new ArrayList<TaskBid>(freeTasks.size());
        
        for (int i = 0; i < freeAgents.size(); i++) {
        	for (int j = 0; j < appTasks.size(); j++) {
        		Task t = appTasks.get(j);
        		if (!t.inapplicable) {
                    Agent a = freeAgents.get(i);
        			int bid = a.computeBid(t);
                    if (bid == 0 || bid == Integer.MAX_VALUE)
                        continue;
                    
                    bids.add(new TaskBid(a, t, bid));
        		}
        	}
        }
        
        
        //Sort the list of bids on all the tasks
        Collections.sort(bids);
        TaskBid bestBid;
        Map map = new Map(realMap, null);
        
        while (!bids.isEmpty()) {
            bestBid = bids.get(0);
            ArrayList<Plan> otherPlans = this.getOtherAgentPlans(bestBid.agent);
            ArrayList<Integer> otherPositions = this.getOtherAgentPositions(bestBid.agent);
            
            //Reject agents who have previously bidded falsely
            Integer agTrials = agentTrials.get(bestBid.agent.id);
            if (agTrials != null && agTrials > 1) {
                bids.remove(0);
                continue;
            }
            
            //Our agent if pristine for computing a plan
        	Plan p = bestBid.agent.computePlan(bestBid.task, otherPlans, otherPositions, new Map(realMap, map));
        	if (p != null) {
        		assignTaskToAgent(bestBid.task, p, bestBid.agent);
                bids.clear(); //Free all bids
            	assignTasks(addNewTasks);
        	}
            else {
            	
            	addBlocingTask(bestBid.task, bestBid.agent);
                //Agent could not create a plan for the bid
                //System.err.println("No plan could be found for "+bestBid);
                //Punish the agent for having bidded falsely
                Integer trials = agentTrials.get(bestBid.agent.id);
                if (trials == null) 
                    trials = 0;
                agentTrials.put(bestBid.agent.id, ++trials);
                bids.remove(0);
            }
        }
        
        //Clear the object global agentTrials map
        this.agentTrials.clear();
	}
	
	private void addBlocingTask(Task task, Agent agent){
		int bbPosition = LookForHelp.getBlockingBox(task, agent);
		
		if(bbPosition == -1)
			return;
		
		Task t = Task.newRemoveBoxTask(agent.id, bbPosition);
		System.err.println("HELP Task box: " + t.boxLetter + " from: "+ Level.coordsToString(t.initBoxPosition) + " to: " + Level.coordsToString(t.goal));
		this.tasks.add(t);
	}
	
	public void moveAwayFreeAgents() {
		ArrayList<Agent> freeAgents = new ArrayList<Agent>();
		for (Agent a : this.agents) {
			if (!a.hasNext())
				freeAgents.add(a);
		}
		
		for (Agent a : freeAgents) {
			ArrayList<Plan> otherPlans = this.getOtherAgentPlans(a);
			ArrayList<Integer> otherPositions = this.getOtherAgentPositions(a);
			Map map = new Map(this.realMap, new Map(this.realMap, null));
			a.computeNonobstructingPlan(otherPlans, otherPositions, map);
		}
	}
	
	private ArrayList<Task> getFreeTasks() {
		ArrayList<Task> freeTasks = new ArrayList<Task>();
		for (Task t : this.tasks) {
			if (!t.isCompleted() && t.owner == null)
				freeTasks.add(t);
		}
		return freeTasks;
	}

	private ArrayList<Plan> getOtherAgentPlans(Agent self) {
		ArrayList<Plan> plans = new ArrayList<Plan>();
		for (Agent a : this.agents) {
			if (a != self && a.hasNext())
				plans.add(a.getPlan());
		}
		return plans;
	}
	
	private ArrayList<Integer> getOtherAgentPositions(Agent self) {
		ArrayList<Integer> positions = new ArrayList<Integer>();
		for (Agent a : this.agents) {
			if (a != self && a.hasNext())
				positions.add(a.position);
		}
		return positions;
	}
    
    /**
     * Assign a single task to the best fitted available agent
     * @param task 
     */
    public void assignTask(Task task) {
        ArrayList<Plan> plans = this.queryAgentsForPlans(task);
        Collections.sort(plans);
        if (plans.isEmpty()) {
            System.err.println("No agents can solve "+task);
            return;
        }
        Plan bestPlan = plans.get(0);
        
        Agent winnerAgent = bestPlan.getCreator();
        this.assignTaskToAgent(task, bestPlan, winnerAgent);
    }
    
    
    /**
     * Query all available agent to come up with a plan for a given task
     * @param task
     * @return an array of plans
     */
    public ArrayList<Plan> queryAgentsForPlans(Task task) {
        ArrayList<Plan> plans = new ArrayList<Plan>(this.agents.size());
        for (Agent a: this.agents) {
            if (a.getCurrentTask() != null) continue; //Skip this agent, it have a task already
            Map map = new Map(realMap, null);
            ArrayList<Plan> otherPlans = this.getOtherAgentPlans(a);
            ArrayList<Integer> otherPositions = this.getOtherAgentPositions(a);
            Plan aPlan = a.computePlan(task, otherPlans, otherPositions, new Map(realMap, map));
            if (aPlan != null)
                plans.add(aPlan);
        }
        
        return plans;
    }
	
    /**
     * Assign a task and plan to an agent
     */
    public void assignTaskToAgent(Task task, Plan plan, Agent agent) {
    	if (task.isStillValid()) {
    		agent.setTaskAndPlan(task,plan);
    	}
    	else
    		System.err.println("TaskDistribute: Task already assigned: "+task);
        /*if (this.freeTasks.contains(task)) {
            this.freeTasks.remove(task);
            agent.setTaskAndPlan(task, plan);
            this.assignedTasks.add(task);
        }
        else
            System.err.println("TaskDistribute: Task already assigned: "+task);*/
    }
    
    
    public void releaseTask(Agent agent) {
    	agent.releaseTask();
        /*Task t = agent.getCurrentTask();
        this.assignedTasks.remove(t);
        agent.setTaskAndPlan(null,null); //remove the task and plan from the agent
        if (t.type == Task.TaskType.GOAL) 
            this.completedTasks.add(t);*/
    }
    
    /**
     * This will create the Task objects from the provided list of goals 
     * and boxes. Tasks will belong to a goal and only have a notion of 
     * the box letter it needs.
     */
    public void createTasks() {
        //Loop though all goals
        while (!this.goals.isEmpty()) {
            int goalPos = this.goals.get(0);
            //Get the goal letter
            char letter = Level.getGoalLetter(this.realMap[goalPos]);
            //Get a box position, this will attach a suited box to the task
            int boxPos = this.boxWithLetter(letter, goalPos);
            //Add the new task to the global tasks array
            //this.freeTasks.add(Task.newGoalTask(boxPos, goalPos, -1));
            this.tasks.add(Task.newGoalTask(boxPos, goalPos, -1));
            
            //Remove the goal from the goal list
            this.goals.remove(0);
        }
        
        //System.err.println(this.freeTasks.size()+" tasks created");
        System.err.println(this.tasks.size()+" tasks created");
    }
    
    /**
     * Return true if there agents not doing anything.
     * @return 
     */
    public boolean availableAgents() {
        for (Agent a: this.agents) {
            Task at = a.getCurrentTask();
            if (at == null) 
                return true;
        }
        return false;
    }
    
    /**
     * Get tasks that no other task depends on.
     * @param tasks
     * @return Array of independent tasks
     */
    private ArrayList<Task> getUndependentTasks(ArrayList<Task> tasks){
    	ArrayList<Integer> dependencies = new ArrayList<Integer>();
    	Map map = new Map(Level.realMap, null);
    	for(Task task : tasks){
    		if (task.isCompleted())
    			continue;
    		int i = task.goal;
    		int free = Level.freedomDegree(i, map);
    		if(free == 1){
    	    	if(Level.isEmpty(Level.realMap[Level.getPosFromPosInDirection(i, ActionDirection.NORTH)]))
    	    		dependencies.addAll(checkInDirection(i, ActionDirection.NORTH));
    	    	if(Level.isEmpty(Level.realMap[Level.getPosFromPosInDirection(i, ActionDirection.SOUTH)]))
    	    		dependencies.addAll(checkInDirection(i, ActionDirection.SOUTH));
    	    	if(Level.isEmpty(Level.realMap[Level.getPosFromPosInDirection(i, ActionDirection.EAST)]))
    	    		dependencies.addAll(checkInDirection(i, ActionDirection.EAST));
    	    	if(Level.isEmpty(Level.realMap[Level.getPosFromPosInDirection(i, ActionDirection.WEST)]))
    	    		dependencies.addAll(checkInDirection(i, ActionDirection.WEST));
    		}	
    	}
    	ArrayList<Task> temp = new ArrayList<Task>();
    	for(Task t : tasks){
    		for(int i : dependencies){
    			if(t.goal == i)
    				temp.add(t);
    		}
    	}
    	tasks.removeAll(temp);
    	return tasks;
    }
    
    //Used By getUndependentTasks to check all the way out of the corridor 
    private ArrayList<Integer> checkInDirection(int p, ActionDirection direction){
    	int pos = p;
    	ArrayList<Integer> dependOn = new ArrayList<Integer>();
    	int degreeOfFreedom = 0;
    	
    	while(degreeOfFreedom < 3){
    		pos = Level.getPosFromPosInDirection(pos, direction);
    		if (pos < 0)
    			break;
    		if(Level.isGoal(Level.realMap[pos])){
    			dependOn.add(pos);
    		}
    		
    		degreeOfFreedom = Level.freedomDegree(pos, new Map(Level.realMap, null));
    	}
    	return dependOn;
    }
    
	/**
	 * Assign all available tasks to agents, so every tasks are assigned to one agent.
	 * The distribution if random at this point, should be something intelligent.
	 * This method MUST take BOX coloring into account. 
     * IF YOU WANT A BETTER ASSIGNMENT, SUBCLASS AND OVERWRITE THIS METHOD!
	 */
	/*public void assign() {
		int count=0;
        while (this.goals.size() > 0) {
            count++;
        	for (int b=0; b<this.boxes.size(); b++) {
            //for (int b=this.boxes.size()-1; b>=0; b--) {
                //if (this.agents.get(i))
                int bpos = this.boxes.get(b);
                int bc = Level.getBoxColor(this.realMap[bpos]);
                
                //Find a box of same color as agent
                for (int i=0;i<this.agents.size(); i++) {
                    int c = Level.getAgentColor(this.agents.get(i).getId());
                    if (bc == c) {
                        // assign box to agent
                        int goal = this.goalForBoxAt(bpos);
                        if (goal == -1) {
                            System.err.println("Cound not find a suited goal for box: "+Level.getBoxLetter(this.realMap[bpos])+" skipping");
                            this.boxes.remove(b);
                            b--;
                            break;
                        }
                        Task at = Task.newAgentApproxTask(this.agents.get(i).getIndexOnMap(), bpos);
                        Task gt = Task.newGoalTask(bpos, goal, this.agents.get(i).getIndexOnMap());
                        System.err.println("TaskDistribute: New "+at.toString()+" for agent "+i);
                        System.err.println("TaskDistribute: New "+gt.toString()+" for agent "+i);
                        this.tasks.add(at);
                        this.tasks.add(gt);
                        this.agents.get(i).addTask(at);
                        this.agents.get(i).addTask(gt);
                        this.boxes.remove(b); //Remove assigned box from list
                        b=0;//this.boxes.size(); //End the inner-loop
                        break;
                    }
                }
            }
        }
        
	}*/
	
    /**
     * Find a suited goal for a given box
     * @deprecated 
     * @param boxpos the position of the box
     * @return the position of the goal, if no goal found return -1
     */
    public int goalForBoxAt(int boxpos) {
        char bl = Character.toLowerCase(Level.getBoxLetter(this.realMap[boxpos]));
        for (int g=0; g<this.goals.size(); g++) {
            int gpos = this.goals.get(g);
            char gl = Character.toLowerCase(Level.getGoalLetter(this.realMap[gpos])); 
            if (bl == gl) {
                this.goals.remove(g); //remove the goal from the available goals
                return gpos;
            }
        }
        return -1;
    }
    
    /**
     * Find the closest available box with the given letter.
     * The same box cannot be found twice, since the box returned are removed 
     * from the list of boxes.
     * @param letter
     * @return box position or -1
     */
    public int boxWithLetter(char letter, int fromPos) {
        ArrayList<BoxCandidate> candidates = new ArrayList<BoxCandidate>(1);
        letter = Character.toLowerCase(letter);
        for(int i=0; i<this.boxes.size(); i++) {
            int b = this.boxes.get(i);
            if (Character.toLowerCase(Level.getBoxLetter(this.realMap[b])) == letter) {
                candidates.add( new BoxCandidate(this.boxes.get(i), fromPos, i) );
            }
        }
        
        if (candidates.isEmpty())
            return -1;
        
        Collections.sort(candidates);
        this.boxes.remove(candidates.get(0).id);
        return candidates.get(0).boxPos;
    }
    
    protected class BoxCandidate implements Comparable {
        
        int boxPos;
        int distance;
        int id;
        
        public BoxCandidate(int boxPosition, int goalPosition, int id) {
            this.boxPos = boxPosition;
            this.distance = Level.shortestDistanceOnMap(boxPos, goalPosition);
            this.id = id;
        }

        @Override
        public int compareTo(Object t) throws UnsupportedOperationException {
            BoxCandidate t2 = (BoxCandidate) t;
            if (t2.distance > this.distance)
                return -1;
            else if (t2.distance < this.distance)
                return 1;
            else
                return 0;
        }
        
    }
    
    /**
     * This is a class to hold task bids
     */
    protected class TaskBid implements Comparable {
        Agent agent;
        Task task;
        int bid;
        
        /**
         * Create a new bid
         * @param a The agent offering this bid
         * @param t The task being bid on
         * @param b The bid value
         */
        public TaskBid(Agent a, Task t, int b) {
            this.agent = a;
            this.task = t;
            this.bid = b;
        }

        @Override
        public int compareTo(Object t) throws UnsupportedOperationException {
            TaskBid t2 = (TaskBid) t;
            if (t2.bid > this.bid)
                return -1;
            else if (t2.bid < this.bid)
                return 1;
            else
                return 0;
        }
        
        @Override
        public String toString() {
            return ("Bid(Agent "+agent.id+" bid on "+task+" with "+bid+")");
        }
    }
}