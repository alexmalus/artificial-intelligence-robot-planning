package aims;

public enum ActionType {
	MOVE, PUSH, PULL, NOOP
}
