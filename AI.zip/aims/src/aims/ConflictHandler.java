package aims;

import java.util.ArrayList;

public class ConflictHandler {

	public static void HandleProblem(PlanConflict pc, ArrayList<Integer> agentPositions) {
		if (pc.size() < 2){
			Plan a1 = pc.get(0);
			a1.insertNoOpsAt(1, 0);
		}
		else {
			Plan a1 = pc.get(0);
			Plan a2 = pc.get(1);
			int step = pc.step;
			recur(a1, a2, step, 200, agentPositions);
		}
	}

	private static void recur(Plan a1, Plan a2, int step, int internalSteps, ArrayList<Integer> agentPositions) {

		a1.insertNoOpsAt(1, 0);
		ArrayList<Plan> plans = new ArrayList<Plan>();
        plans.add(a1);
		plans.add(a2);
		ArrayList<PlanConflict> pc = Plan.consolidatePlans(plans, -1, agentPositions);

		if (pc == null || pc.isEmpty()) {
			a1.insertNoOpsAt(1, 0);
		} else if (pc.get(0).size() < 2){
			//a1.getPlan().insertNoOpsAt(1, 0);
		}
		else if (internalSteps > 0) {
			--internalSteps;

			recur(a1, a2, pc.get(0).step, internalSteps,agentPositions);
		} else {

		}

	}
}
