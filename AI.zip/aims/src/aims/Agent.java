
package aims;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import aims.Task.TaskType;

public class Agent {
	protected int color; //the color integer defined in the Level class
	protected int id;
	protected int position;
	protected Plan curPlan;
	protected Task curTask;

	public Agent(int row, int column, int color, int id) {
		this.color = color;
		this.position = Level.getIndexFromColoumnAndRow(column,row);
		this.id = id;
	}

	public int getId() {return this.id;}

	/**
	 * Gives the agents current position on the real map
	 * @return position index
	 */
	public int getIndexOnMap() {
		return this.position;
	}

	/**
	 * Assign a specified task to this agent.
	 * This should be called by the taskDistributer class.
	 * @param task
	 */
	public void setTask(Task task) {
		if (this.curTask != null) 
			this.curTask.unassign();

		if (task != null) 
			task.assign(this);

		if (task != null)
			System.err.println("Agent " + this.id + " got task: " + task.toString());

		this.curTask = task;
	}

	public void setTaskAndPlan(Task task, Plan plan) {
		this.setTask(task);
		this.setPlan(plan);
	}

	public void setPlan(Plan p) {
		this.curPlan = p;
	}

	/**
	 * will be called when an action fails, which is assumed to be only when a
	 * hidden object (wall) has been discovered.
	 */
	public void releaseTask() {
		this.setTask(null);
		this.setPlan(null);
	}

	/*public Plan getPlan() {
		return curPlan;
	}*/

	public boolean hasNext() {
		return (curPlan != null && curPlan.size() > 0);
	}

	public Action getNextAction() {
		if (this.hasNext()){
			Action a = curPlan.get(0);
			curPlan.remove(0);
			return a;
		}
		return null;
	}

	public Plan getPlan() {
		return this.curPlan;
	}

	public void addActionToHead(Action a) {
		curPlan.add(0,a);
	}

	public Task getCurrentTask() {
		return this.curTask;
	}

	public int computeBid(Task t) {
		if (t == null)
			return Integer.MAX_VALUE;
		t.fix();
		if (t.type == Task.TaskType.GOAL && t.getColor() == Level.getAgentColor(this.id)) {
			return (int) (Level.shortestDistanceOnMap(this.position, t.initBoxPosition)
					+ Level.shortestDistanceOnMap(t.initBoxPosition, t.targetBoxPosition));
		}
		else if(t.type == Task.TaskType.REMOVEBOX && t.getColor() == Level.getAgentColor(this.id)){
			return (int) (Level.shortestDistanceOnMap(this.position, t.initBoxPosition));
		}
		return Integer.MAX_VALUE;

		/*Plan p = this.computePlan(t);
    	return p != null ? p.size() : Integer.MAX_VALUE;*/
	}

	public Plan computeOterPlan(Task t, ArrayList<Plan> otherPlans, ArrayList<Integer> otherPositions, Map map){

		AstarProblem p = t.convertToAstarProblem(this.position, otherPlans, otherPositions, map);
		p.agentColor = this.color;
		p.setInit();

		astar.Solution<Action,State> solution1 = astar.AStar.solve(p, 10000);

		;

		p.shouldMoveBoxesBack = false;
		solution1 = astar.AStar.solve(p, 40000);

		if(solution1 == null) return null;
		Plan plan = new Plan(this);
		for (int i = 1; i < solution1.getPath().size(); i++)
			plan.add(solution1.getPath().get(i).action);


		return plan;

	}


	/**
	 * computes a plan for the first applicable task in the task list
	 * returns: true if a new plan has been found or false if no applicable plans
	 */
	public Plan computePlan(Task t, ArrayList<Plan> otherPlans, ArrayList<Integer> otherPositions, Map map){

		//Reject if task is null, or the task has a different color
		if (t == null|| t.getColor() != Level.getAgentColor(this.id))
			return null;

		if(t.type == TaskType.REMOVEBOX){
			return computeOterPlan(t, otherPlans, otherPositions, map); }

		// Solve first half of the problem
		Task moveToBox = Task.newAgentApproxTask(this.id, t.initBoxPosition);
		AstarProblem p1 = moveToBox.convertToAstarProblem(this.position, otherPlans, otherPositions, map);
		if (p1 == null) return null;
		p1.setInit();
		//System.err.println("Tries to solve: " + moveToBox);
		astar.Solution<Action,State> solution1 = astar.AStar.solve(p1, 5000);

		//try again moving boxes away from goal and not back 
		if (solution1 == null){
			p1.shouldMoveBoxesBack = false;
			solution1 = astar.AStar.solve(p1, 5000);
		}

		if(solution1 == null) return null;

		// Solve second half of the problem
		State gs = solution1.goalState;
		Task moveBoxToGoal = Task.newGoalTask(t.initBoxPosition, t.targetBoxPosition, this.id);
		AstarProblem p2 = moveBoxToGoal.convertToAstarProblem(gs.playerLocation, otherPlans, otherPositions, gs.map);
		if(t.type == TaskType.REMOVEBOX){
			p2.agentColor = this.color;
		}
		if (p2 == null) return null;
		p2.setInit();
		p2.init.state.boxPosition = t.initBoxPosition;
		p2.init.state.time = gs.time;
		p2.init.state.otherAgentPositions = gs.otherAgentPositions;
		p2.init.state.boxesMovedFromGoal = gs.boxesMovedFromGoal;
		System.err.println("Agent " + this.id + " tries to solve: " + moveBoxToGoal);
		astar.Solution<Action,State> solution2 = astar.AStar.solve(p2, 5000);

		//try again moving boxes away from goal and not back 
		if (solution2 == null){
			System.err.println("Failed, try again 2");
			p2.shouldMoveBoxesBack = false;
			solution2 = astar.AStar.solve(p2, 5000);
		}
		if (solution2 == null) return null;

		//Indicate to the garbage collector that we have memory that can be freed
		System.gc();

		//Create a plan from the two-part solution
		Plan plan = new Plan(this);
		for (int i = 1; i < solution1.getPath().size(); i++)
			plan.add(solution1.getPath().get(i).action);
		for (int i = 1; i < solution2.getPath().size(); i++)
			plan.add(solution2.getPath().get(i).action);
		return plan;
	}



	private void commitCachePlan(Task t){
		int boxPosition=t.initBoxPosition;
		int goalPosition=t.goal;

		ArrayList<Integer> cacheList=calculateContingencyCache(boxPosition,goalPosition);

		for(int i=0;i<cacheList.size();i++){
			int temPosition=cacheList.get(i);
		}
	}

	// calculate the contingency cache list by removing the shortest path list from the empty list
	// the rest of the positions in the empty list can be used as a cache
	private ArrayList calculateContingencyCache(int from, int goal){	
		ArrayList<Integer> emptyPositions =new ArrayList<Integer>();
		emptyPositions=Level.getCachePosition();

		ArrayList<Integer> sdl =new ArrayList<Integer>();
		sdl=Level.shortestPathList(from, goal);

		for(int i=0;i<emptyPositions.size();i++){
			for(int j=0;j<sdl.size();j++){
				if(emptyPositions.get(i)==sdl.get(j))
					emptyPositions.remove(i);

			}		
		}
		Collections.sort(emptyPositions);

		return emptyPositions;
	}

	public void computeNonobstructingPlan(ArrayList<Plan> otherPlans, ArrayList<Integer> otherPositions, Map map) {
		Task t = Task.newNonobstructingTask(this.id);
		AstarProblem p = t.convertToAstarProblem(this.position, otherPlans, otherPositions, map);
		p.agentColor = this.color;
		p.setInit();
		astar.Solution<Action,State> s = astar.AStar.solve(p, 10000);

		System.gc();

		if (s == null) return;

		//Create a plan from the two-part solution
		Plan plan = new Plan(this);
		for (int i = 1; i < s.getPath().size(); i++)
			plan.add(s.getPath().get(i).action);
		this.setTaskAndPlan(t, plan);

	}

	public String toString() {
		return "Agent "+this.id+": "+(this.hasNext() ? 1 : 0)+" tasks. Have plan now: "+(this.curPlan!=null?"YES":"NO");
	}
}

