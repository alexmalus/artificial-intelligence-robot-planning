package aims;

import java.util.ArrayList;
import java.util.HashSet;

public class TimePlaceConstraint extends ArrayList<HashSet<Integer>> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6928612388191458850L;

	/**
	 * This method determines if a given position at a given time in the future
	 * conflicts with any of the locations in the existing list of time-based
	 * constrains, i.e. other agent's interaction with the map.
	 * @param time Time in the future to check for conflicts
	 * @param position Position on the map to check for conflicts on
	 * @return True if there is a conflict in the given time and position
	 */
	public boolean conflicts(int time, int position) {
		if (this.size() == 0)
			return false;
		if (this.size() < time + 1) {
			return this.conflicts(this.size() - 1, position);
		}
		return this.get(time).contains(position);
	}
	
	public boolean conflicts(int time, ArrayList<Integer> positions) {
		for (int i : positions) {
			if (this.conflicts(time, i))
				return true;
		}
		return false;
	}
	
	/**
	 * This method will add all actions from a given plan to a list of time-
	 * place constraints, such that other agents shouldn't try to access those
	 * locations at the same time.
	 * @param p The plan to add all actions from
	 * @param initPosition The initial position of the agent with the given plan
	 */
	public void addAllFromPlan(Plan p, int initPosition) {
		if (p == null)
			return;
		
		HashSet<Integer> lastInts = this.size() > 0 ? this.get(this.size()-1) : null;
		
		int curPos = initPosition;
		
		// Add all the actions in the plan
		for (int i = 0; i < p.size(); i++) {
			HashSet<Integer> hs;
			if (this.size() < i + 1) {
				hs = new HashSet<Integer>();
				if (lastInts != null)
					hs.addAll(lastInts);
				this.add(hs);
			}
			else
				hs = this.get(i);
			
			Action a = p.get(i);
			if (a == null) continue;
			hs.addAll(a.addToArraylist(curPos));
			curPos = a.newAgentPosition(curPos);
		}
		
		// If the given plan is shorter than the otherwise maximum plan, add the
		// last step of this plan to all subsequent steps in the TPC
		ArrayList<Integer> pos = p.get(p.size()-1).addToArraylist(curPos);
		for (int i = p.size(); i < this.size(); i++) {
			this.get(i).addAll(pos);
		}
	}
}
