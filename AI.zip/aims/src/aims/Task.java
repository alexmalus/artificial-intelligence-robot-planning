package aims;

import java.util.ArrayList;

/**
 * <p>A task is the process of moving a BOX to a GOAL. The task contains a goal
 * position and a box position. These will have matching letters. Tasks also
 * have a color, indicating what agents can handle this task.</p>
 *
 * @author kristoffer
 */
public class Task {

	public enum TaskType {
		GOAL, BOX, AGENT, AGENTAPPROX, NONOBSTRUCTING, REMOVEBOX
	}
	protected int goal = -1;
	protected int initBoxPosition = -1;
	protected int boxId = -1;
	protected int initAgentPosition = -1;
	protected int targetAgentPosition = -1;
	protected int targetBoxPosition = -1;
	protected int[] realMap;
	protected int agentID;
	protected TaskType type;
	protected ArrayList<Task> dependencies;
	protected boolean completed = false;
	protected Agent owner;
	//protected Color color;
	protected Level level;

	/**
	 * If we have a initBox save its letter here
	 * TODO: actually set boxLetter, or don't use it!
	 */
	protected char boxLetter;

	/**
	 * A task might get invalid, if it does this will be true
	 * Only applicable task are allowed to execute
	 */
	protected boolean inapplicable = false;

	/**
	 * Assign this task to an agent
	 * @param own 
	 */
	public void assign(Agent own) {
		this.owner = own;
		//Update this tasks agent start position to the position of the new owner
		this.initAgentPosition = this.owner.position;
		this.agentID = this.owner.id;

		//if (Level.getBoxColor(this.realMap[this.initBoxPosition]) != Level.getAgentColor(this.agentID)) {
		//    System.out.println("Agent "+this.agentID+" assign to non applicable task. Colors differ!");
		//}
	}

	/**
	 * Release this task from any assigned agent
	 */
	public void unassign() {
		this.owner = null;
		this.initAgentPosition = -1;
		this.agentID = -1;
	}

	/**
	 * Mark this task as inapplicable
	 * This means it cannot be completed/executed at this moment
	 */
	public void markAsInapplicable() {
		this.inapplicable = true;
	}

	/**
	 * Mark this task as applicable
	 * This means it <i>can</i> be completed/executed at this moment
	 */
	public void markAsapplicable() {
		this.inapplicable = false;
	}

	/**
	 * Return the color of this task. Only agents of the same color as the task 
	 * can be assigned to this.
	 * @return 
	 */
	public int getColor() {
		if (this.initBoxPosition != -1)
			return Level.getBoxColor(this.realMap[this.initBoxPosition]);
		else
			return -1;
	}

	public void addDenpendency(Task t) {
		if (!this.dependencies.contains(t)) {
			this.dependencies.add(t);
		}
	}

	public int getAgentID() {
		return agentID;
	}

	//	public void setAgentID(int agentID) {
	//		this.agentID = agentID;
	//	}
	/**
	 * Return the position of this tasks goal position. This if only valid if
	 * the task is a GOAL task
	 *
	 * @return
	 */
	public int getGoal() {
		return goal;
	}

	/**
	 * @deprecated Dont use this!
	 * @param goal
	 */
	public void setGoal(int goal) {
		this.goal = goal;
	}
	public int getInitBoxPosition() {
		return initBoxPosition;
	}

	public void setInitBoxPosition(int initBoxPosition) {
		if (this.type == TaskType.AGENT || this.type == TaskType.AGENTAPPROX) {
			return;
		}
		if (!Level.isBox(this.realMap[initBoxPosition])) {
			System.err.println("Task: Cannot set initial box position on field not containing a box, pos: " + initBoxPosition);
		} else {
			this.initBoxPosition = initBoxPosition;
			this.boxId = Level.getBoxIdFromPosition(initBoxPosition);
			this.boxLetter = Level.getBoxLetter(this.realMap[initBoxPosition]);
		}
	}

	/**
	 * @deprecated Use the agent to get its position
	 * @return
	 */
	public int getInitAgentPosition() {
		return initAgentPosition;
	}

	/**
	 * @deprecated This will mess up owner agent relationship to task!
	 * @return
	 */
	public void setInitAgentPosition(int initAgentPosition) {
		this.agentID = Level.getAgentId(this.realMap[initAgentPosition]);
		this.initAgentPosition = initAgentPosition;
	}
	public int getTargetAgentPosition() {
		return targetAgentPosition;
	}

	public void setTargetAgentPosition(int targetAgentPosition) {
		this.targetAgentPosition = targetAgentPosition;
	}

	public int getTargetBoxPosition() {
		return targetBoxPosition;
	}

	public void setTargetBoxPosition(int targetBoxPosition) {
		this.targetBoxPosition = targetBoxPosition;
	}

	public void setTaskAsCompleted() {
		this.completed = true;
	}

	/**
	 * Check if a task complete condition is satified, at this moment.
	 * @return 
	 */
	public boolean isCompleted() {
		switch (this.type) {
		case GOAL:
			return Level.isBox(this.realMap[this.goal]) && Level.boxIsOnItsGoal(this.realMap[this.goal]);
		case BOX:
			System.err.println("Task warning, isCompleted() might not work for BOX tasks");
			return (this.boxLetter == Level.getBoxLetter(this.realMap[this.targetBoxPosition]));
		case AGENT:
			return (this.owner != null && this.owner.position == this.targetAgentPosition);
		case AGENTAPPROX:
			return (this.owner != null && Level.isNeighbor(this.owner.position, this.targetAgentPosition));
		case REMOVEBOX:
			if(this.targetBoxPosition == -1) return false;
			if(Level.isBox(this.realMap[this.targetBoxPosition]) && this.boxLetter == Level.getBoxLetter(this.realMap[this.targetBoxPosition])){
				this.completed = true;
			}
			return(this.completed);
		default:
			return false;
		}
	}

	/**
	 * Create a task with a box and a goal to move the box to. This constructor
	 * will check if the box and goal are applicable (letters match) and
	 * determine the color of the task
	 *
	 * @param box The box position to move to the goal
	 * @param goal A goal position
	 * @param curAgent A agent position
	 */
	public static Task newGoalTask(int curBox, int goal, int curAgent) {
		Task self = new Task(TaskType.GOAL, goal);
		//TODO: Check if agent and box are of the same color and box and goal letters match

		self.setInitBoxPosition(curBox);

		//This is set by the .assign() method
		//self.setInitAgentPosition(curAgent);

		self.setTargetBoxPosition(goal);
		return self;
	}

	/**
	 * Task of moving only an agent from one position to another
	 *
	 * @param curAgent
	 * @param targetAgent
	 */
	public static Task newAgentTask(int curAgent, int targetAgent) {
		Task self = new Task(TaskType.AGENT, -1);
		//TODO: Check if agent and box are of the same color and box and goal letters match

		//This is set by the .assign() method
		//self.setInitAgentPosition(curAgent);
		self.agentID = curAgent;
		self.setTargetAgentPosition(targetAgent);

		return self;
	}

	/**
	 * Task of moving only an agent from one position to a neighbor to a another
	 * position. THis will move a player (agent) to a approximate position.
	 *
	 * @param curAgent
	 * @param approxTargetAgent
	 */
	public static Task newAgentApproxTask(int curAgent, int approxTargetAgent) {
		Task self = new Task(TaskType.AGENTAPPROX, -1);
		//TODO: Check if agent and box are of the same color and box and goal letters match

		// This will be set by the .assign() method
		//self.setInitAgentPosition(curAgent);
		self.agentID = curAgent;
		self.setTargetAgentPosition(approxTargetAgent);

		return self;
	}

	public static Task newNonobstructingTask(int curAgent) {
		Task self = new Task(TaskType.NONOBSTRUCTING, -1);
		self.agentID = curAgent;

		return self;
	}

	public static Task newRemoveBoxTask(int curAgent, int initBoxPosition) {
		Task self = new Task(TaskType.REMOVEBOX, initBoxPosition);
		self.agentID = curAgent;
		self.setInitBoxPosition(initBoxPosition);

		return self;
	}

	public Task(TaskType type, int goalPos) {
		this.level = Level.getSingletonObject();
		this.realMap = Level.realMap;
		this.type = type;
		this.dependencies = new ArrayList<Task>(1);
		this.goal = goalPos;
	}

	/**
	 * Moving a box from one position to another. Not to a goal position
	 *
	 * @param curBox
	 * @param targetBox
	 */
	public static Task newBoxTask(int curBox, int targetBox, int curAgent) {
		Task self = new Task(TaskType.BOX, -1);
		//TODO: Check if agent and box are of the same color
		if (Level.getBoxColor(self.realMap[curBox]) != Level.getAgentColor(self.realMap[curAgent])) {
			System.err.println("agentcolor and box color does not match");
			return null;
		}


		self.setInitBoxPosition(curBox);

		//This is set by the .assign() method
		//self.setInitAgentPosition(curAgent);
		self.setTargetBoxPosition(targetBox);

		return self;
	}

	/**
	 * Return true if all dependencies for this task is met.
	 * @deprecated Needs rewrite if used, might not work
	 * @return
	 */
	public boolean dependenciesCleared() {
		if (this.dependencies.size() <= 0) {
			return true;
		} else {
			for (Task t : this.dependencies) {
				if (!(t.isCompleted() && t.type == TaskType.GOAL)) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Convert a task instance to an Astar ProblemInstance
	 *
	 * @param a
	 * @return
	 */
	public AstarProblem convertToAstarProblem(int agentPosition,
			ArrayList<Plan> otherPlans, ArrayList<Integer> otherPositions, Map map) {

		this.fix();

		if (!this.dependenciesCleared()) {
			System.err.println("Creating Astar problem from task (" + this.toString() + ") which has unmet dependencies!");
		}

		//clone the map
		/*int[] newMap = new int[realMap.length];
        for (int i = 0; i < realMap.length; i++) {
            newMap[i] = realMap[i];
        }*/

		return new AstarProblem(map, agentPosition, initBoxPosition, targetAgentPosition, targetBoxPosition, goal, this,
				otherPlans, otherPositions);

	}

	public int getCost(int currentPosition, Map currentMap, Action currentAction) {
		//if (currentAction.type() == ActionType.NOOP)
		//	return 2;

		if (this.type == TaskType.AGENTAPPROX || this.type == TaskType.NONOBSTRUCTING) {
			if (currentAction.type() == ActionType.MOVE)
				return 1;
			return 2;
		}

		return 1;
		/*int boxPos;
        switch (currentAction.type) {
            case MOVE:
                if (this.type == TaskType.AGENT || this.type == TaskType.AGENTAPPROX) {
                    return 1;
                } else {
                    return 10;
                }
            case PUSH:
            case PULL:
                if (currentAction.type == ActionType.PUSH) {
                    boxPos = Level.getPosFromPosInDirection(currentPosition, currentAction.direction);
                } else {
                    boxPos = Level.getPosFromPosInDirection(currentPosition, currentAction.boxDirection);
                }
                //Are we moving a box on its goal
                if (Level.boxIsOnItsGoal(currentMap.get(boxPos))) {
                    return 20;
                }
                else {
                    if (this.type != TaskType.AGENT && this.type != TaskType.AGENTAPPROX 
                            && Level.getBoxLetter(currentMap.get(boxPos)) == this.boxLetter) {
                        return 1;
                    } else {
                        return 10;
                    }
                }
            default:
                return 10;
        }*/
	}

	public boolean isGoal(astar.Node<Action, State> node, boolean shouldMoveBoxesBack, int color) {
		if (shouldMoveBoxesBack &&
				(node.state.boxesMovedFromGoal > 0 ||
						(this.type == TaskType.GOAL && node.state.boxesMovedFromGoal > -1)))
			return false;

		if (this.type == TaskType.AGENT && this.targetAgentPosition == node.state.playerLocation) {
			return true;
		}
		if (this.type == TaskType.BOX && this.targetBoxPosition == node.state.boxPosition) {
			return true;
		}
		if (this.type == TaskType.AGENTAPPROX && Level.isNeighbor(this.targetAgentPosition, node.state.playerLocation)) {
			return true;
		}
		if (this.type == TaskType.GOAL && /*this.targetBoxPosition == node.state.boxPosition
                && Character.toLowerCase(Level.getBoxLetter(node.state.map.get(node.state.boxPosition)))
                == Character.toLowerCase(Level.getGoalLetter(Level.realMap[this.targetBoxPosition]))*/
				Level.isBox(node.state.map.get(this.targetBoxPosition)) &&
				Level.boxIsOnItsGoal(node.state.map.get(this.targetBoxPosition))) {
			return true;
		}
		if (this.type == TaskType.NONOBSTRUCTING && !Level.isObstructing(node.state.playerLocation, node.state.map, color))
			return true;
		if (this.type == TaskType.REMOVEBOX ){
			if(node.state.boxPosition == -1) return false;
			if (Level.isEmpty(node.state.map.get(this.initBoxPosition)) &&
					!Level.isObstructing(node.state.boxPosition, node.state.map, color)){
				this.targetBoxPosition = node.state.boxPosition;
				return true;
			}
		}

		return false;
	}

	public int getMoveCost() {
		return (this.type == TaskType.AGENT || this.type == TaskType.AGENTAPPROX) ? 1 : 20;
	}

	/**
	 * Corrects the Box position if it has moved
	 */
	public void fix() {
		//correct task if box has moved
		if ((this.type != TaskType.AGENT && this.type != TaskType.AGENTAPPROX && this.type != TaskType.NONOBSTRUCTING) && (this.initBoxPosition == -1 || !Level.isBox(this.realMap[this.initBoxPosition]))) {

			//Search for a box with the same letter
			this.initBoxPosition = -1;
			for (int i=0; i<this.realMap.length; i++) {
				int f = this.realMap[i];
				if (Level.isBox(f) && !Level.boxIsOnItsGoal(f) && Level.getBoxLetter(f) == this.boxLetter) {
					this.initBoxPosition = i;
					break;
				}
			}

			if (this.initBoxPosition == -1) {
				System.err.println("Task: Could not Fix box position");
				this.markAsInapplicable();
			}
			else 
				System.err.println("Task: Fixed box position, found the box at pos: "+this.initBoxPosition);
		}
	}

	/**
	 * This will tell if a tasks goal is still on
	 * the correct goal position. THis is ONLY applicable on GOAL tasks
	 * @return 
	 */
	public boolean isStillValid() {
		if (this.type == TaskType.GOAL) {
			if (!this.completed) return true;
			if (Level.boxIsOnItsGoal(this.realMap[this.targetBoxPosition]))
				return false;
			else {
				this.completed = false;
				this.fix();
				return false;
			}
		}
		else {
			System.err.println("Task: isCompleted not applicable on non-goal tasks!");
			return true;
		}
	}

	/**
	 * Return a human readable string describing this task
	 *
	 * @return
	 */
	@Override
	public String toString() {
		this.fix();
		String out = "Task(";
		int x, y;
		switch (this.type) {
		case GOAL:
			out += "Box " + Level.getBoxLetter(this.realMap[this.initBoxPosition]) + " -> Goal " + Level.getGoalLetter(this.realMap[this.goal]) + ")";
			break;
		case AGENT:
			x = Level.getColumnFromIndex(this.targetAgentPosition);
			y = Level.getRowFromIndex(this.targetAgentPosition);
			out += "Agent " + this.agentID + " -> Position (" + x + "," + y + ") )";
			break;
		case AGENTAPPROX:
			x = Level.getColumnFromIndex(this.targetAgentPosition);
			y = Level.getRowFromIndex(this.targetAgentPosition);
			out += "Agent " + this.agentID + " -> Approx Position (" + x + "," + y + ") )";
			break;
		case BOX:
			x = Level.getColumnFromIndex(this.targetBoxPosition);
			y = Level.getRowFromIndex(this.targetBoxPosition);
			out += "Box " + Level.getBoxLetter(this.realMap[this.initBoxPosition]) + " -> Position (" + x + "," + y + ") )";
			break;
		case NONOBSTRUCTING:
			out += "Agent non-obstruct)";
			break;
		case REMOVEBOX:
			out += "Remove Box " + this.boxLetter +")";
			break;
		default:
			out += "UNKOWN)";
		}
		return out;
	}

}