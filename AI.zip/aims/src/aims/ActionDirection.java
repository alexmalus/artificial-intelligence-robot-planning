package aims;

public enum ActionDirection {
	NORTH, EAST, SOUTH, WEST
}
