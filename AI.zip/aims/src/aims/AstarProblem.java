package aims;//the problem file instantiated

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

import astar.Node;
import astar.Problem;

public class AstarProblem extends Problem<Action,State>{			//
	HashMap<State, HashMap<Action,State>> successor;
	Map map;
	private int curPlayerLocation; //bruges i init
	private int targetPlayerLocation;
	private int targetBoxLocation;
	private int curBoxLocation; //bruges i init
	private int goalLocation;
	protected boolean shouldMoveBoxesBack = true;
	protected int moveCost = 1; // set from task
	protected int pushCost = 1; // set from task
	protected int pullCost = 1; // set from task
    protected Task parentTask;
    protected int agentColor = 0;
    private ArrayList<Plan> otherPlans;
    private ArrayList<Integer> otherPositions;

/*	public AstarProblem(int[] internalMap, int curPlayerLocation, int curBoxLocation, int targetPlayerLocation, int targetBoxLocation, int goalLocation){
		this.internalMap=internalMap;
		this.curPlayerLocation = curPlayerLocation;
		this.curBoxLocation = curBoxLocation;
		this.targetPlayerLocation = targetPlayerLocation;
		this.targetBoxLocation = targetBoxLocation;
		this.goalLocation = goalLocation;
	}*/

	public AstarProblem(Map m, int curPlayerLocation, int curBoxLocation, int targetPlayerLocation, int targetBoxLocation,
			int goalLocation, Task task, ArrayList<Plan> otherPlans, ArrayList<Integer> otherPositions){
		this.map = m;
		this.curPlayerLocation = curPlayerLocation;
		this.curBoxLocation = curBoxLocation;
		this.targetPlayerLocation = targetPlayerLocation;
		this.targetBoxLocation = targetBoxLocation;
		this.goalLocation = goalLocation;
		this.parentTask = task;
		this.otherPlans = otherPlans;
		this.otherPositions = otherPositions;
	}

	//hører ikke til her, flyttes når der er styr på det hele.
	public boolean isFree(int field){
		return (field & 7)==0;
	}
	final static int  colorFilter = 15<<9;
	public boolean boxApplicable(int playerfield, int boxfield){
		return (boxfield & 2) == 2 && (playerfield & (colorFilter)) == (boxfield & (colorFilter));
	}

	private static List<Action> actions = new LinkedList<Action>();

	public static List<Action> getActions(){
		if(actions.size()==0){
			//move actions
			for(ActionDirection d: ActionDirection.values()){
				actions.add(new Action(d));
			}
			//push actions
			for(ActionDirection d: ActionDirection.values()){
				for(ActionDirection e: ActionDirection.values()){
					if(Action.opposite(d) != e )
						actions.add(new Action(ActionType.PUSH,d,e));
				}
			}
			//pull actions
			for(ActionDirection d: ActionDirection.values()){
				for(ActionDirection e: ActionDirection.values()){
					if(d !=e )
						actions.add(new Action(ActionType.PULL,d,e));
				}			
			}
			actions.add(new Action(ActionType.NOOP));
		}
		return actions;
	}
	private static List<Action> moveActions = new LinkedList<Action>();

	public static List<Action> getMoveActions(){
		if(moveActions.size()==0){
			for(ActionDirection d: ActionDirection.values()){
				moveActions.add(new Action(d));
			}
		}
		return moveActions;
	}

	public TreeSet<Node<Action,State>> expand(Node<Action,State> n){//successor function for 
		TreeSet<Node<Action,State>> successors = new TreeSet<Node<Action,State>>();
		
		ArrayList<Action> otherActions = new ArrayList<Action>();
		for (int i = 0; i < otherPlans.size(); i++) {
			Plan p = otherPlans.get(i);
			Action a = n.state.time < p.size() ? p.get(n.state.time) : null;
			otherActions.add(a);
		}
		
		for(Action a : AstarProblem.getActions()){
			if (a.conflicts(n.state.playerLocation, n.state.otherAgentPositions, otherActions))
				continue;
			
			State newstate = n.state.applyAction(a);
			
			if (newstate != null) {
				boolean shouldContinue = false;
				for (int i = 0; i < otherActions.size(); i++) {
					Action newA = otherActions.get(i);
					if (newA != null) {
						if (!Level.applyAction(newstate.map, newA, n.state.otherAgentPositions.get(i), true)) {
							shouldContinue = true;
							break;
						}
					}
				}
				
				if (shouldContinue) continue;
				
				newstate.otherAgentPositions = Action.getUpdatedPositions(n.state.otherAgentPositions, otherActions);
				successors.add(new Node<Action,State>(a,newstate,n));
			}
		}
		
		return successors;
	}


	//can gøres mere elegant
	public void setInit(){
		Map initMap = new Map(map.map,map);
		this.init= new Node<Action,State>(null, new State(initMap,curPlayerLocation,curBoxLocation), null);
		this.init.state.otherAgentPositions = this.otherPositions;
		//this.init.h=(heuristic(this.init));
		//			this.init.state=new State(modifyMap(s.map, colors), s.playerfield);
		//			this.init.h=computeh(this.init);
	}


	public double cost(astar.Node<Action,State> n, astar.Node<Action,State> suc){
		//return 1;
        //If a parent task is defined, we delegate the cost handling to the task
        if (this.parentTask != null) 
            return (double) this.parentTask.getCost(n.state.playerLocation, n.state.map, suc.action);
        
		int stepCost=0;
        int boxPos = -1;
		switch (suc.action.type()) {
		case MOVE:
			stepCost += this.moveCost;
			break;
		case PUSH:
			
            boxPos = Level.getPosFromPosInDirection(n.state.playerLocation, suc.action.direction());
            //Are we moving a box on its goal
            if (this.boxIsOnGoal(n.state.map.get(boxPos)))
                stepCost += 20;
            else 
                stepCost += this.pushCost;
			break;
		case PULL:
            boxPos = Level.getPosFromPosInDirection(n.state.playerLocation, suc.action.boxDirection());
            //Are we moving a box on its goal
            if (this.boxIsOnGoal(n.state.map.get(boxPos))) {
                stepCost += 20;
            }
            else 
                stepCost += this.pullCost;
			break;
		default:
			break;
		}

		//return 1;
		return stepCost;
	}
    
    /**
     * Check if a field is a box on its goal
     * @param field
     * @return 
     */
    protected boolean boxIsOnGoal(int field) {
        if (Level.isGoal(field) 
           && Character.toLowerCase(Level.getBoxLetter(field))
           == Character.toLowerCase(Level.getGoalLetter(field))
           ) {
            return true;
        }
        else 
            return false;
    }

	//arbejde med at designe en fornuftigt goal funktion
    @Override
	public boolean isGoal(Node<Action,State> n){
        //If we have a parent task, delegate the goal check to that
        if (this.parentTask != null)
            return this.parentTask.isGoal(n, this.shouldMoveBoxesBack, this.agentColor);
        
		//test the case where we have an agentTask
		if(targetBoxLocation==-1){
			if(n.state.playerLocation==targetPlayerLocation)
				return true;
		}
		//if we have a box to goal task or
		else if(goalLocation !=-1){
			if (n.state.boxPosition==targetBoxLocation && Level.getBoxLetter(n.state.map.get(n.state.boxPosition))==Character.toUpperCase(Level.getGoalLetter(n.state.map.get(goalLocation))))
			{return true;}
		}

		//if we have a box to a field different than a goal
		else if(targetBoxLocation!=-1){
			if(n.state.boxPosition==targetBoxLocation ){
				return true;
			}
		}

		return false;

	}
	
	public static double manhattanDistance(int i, int j) {
		int dx = Math.abs(Level.getRowFromIndex(i) - Level.getRowFromIndex(j));
		int dy = Math.abs(Level.getColumnFromIndex(i) - Level.getColumnFromIndex(j));
		return dx + dy;
	}

	/**Calculates a heuristic value based on the current state, it returns the manhattan distance to 
	 * the targetbox position if that is ticked, and the targetplayer position if ticked.
	 * if both are ticked, then we add the two
	 * 
	 */
	public double heuristic(Node<Action,State> n) {
		double h = 0;
		switch (this.parentTask.type) {
		case GOAL:
			h += /*AstarProblem.manhattanDistance(n.state.boxPosition, targetBoxLocation)
			+*/ Level.shortestDistanceOnMap(n.state.boxPosition,parentTask.targetBoxPosition)
			+ Level.shortestDistanceOnMap(n.state.playerLocation, n.state.boxPosition) - 1;
			break;
		case BOX:
			System.err.println("UNKNOWN HEURISTIC FOR BOX-TYPE TASK");
			break;
		case AGENT:
			h += AstarProblem.manhattanDistance(n.state.playerLocation, targetPlayerLocation);
			break;
		case AGENTAPPROX:
			int pl = n.state.playerLocation;
			int gl = parentTask.targetAgentPosition;
			//h += AstarProblem.manhattanDistance(pl,gl) - 1;
			h += Level.shortestDistanceOnMap(pl, gl) - 1;
			break;
		default:
			break;
		}
		
		return 1 * h /*+ n.state.boxesMovedFromGoal*/;
	}
	
	/*private int[] distancesToGoal;
	private LinkedList<Integer> frontSet = new LinkedList<Integer>();
	private boolean instantiatedDistances = false;
	
	private int distanceToGoal(int coord) {
		int goal = parentTask.type == TaskType.GOAL ? parentTask.targetBoxPosition : parentTask.targetAgentPosition;
		
		if (coord == goal)
			return 0;
		
		if (!instantiatedDistances) {
			frontSet.add(goal);
			distancesToGoal = new int[map.map.length];
			distancesToGoal[goal] = 0;
			instantiatedDistances = true;
		}
		
		int dist = distancesToGoal[coord];
		while (dist == 0 && frontSet.size() > 0) {
			dist = distancesToGoal[coord];
			
			int next = frontSet.poll();
			int thisDist = distancesToGoal[next];
			
			List<Integer> neighbors = Arrays.asList(
				Level.getPosFromPosInDirection(next, ActionDirection.EAST),
				Level.getPosFromPosInDirection(next, ActionDirection.WEST),
				Level.getPosFromPosInDirection(next, ActionDirection.NORTH),
				Level.getPosFromPosInDirection(next, ActionDirection.SOUTH));
			
			for (int i : neighbors) {
				if (i > 0 && !Level.isWall(map.map[i]) && distancesToGoal[i] == 0 && i != goal) {
					frontSet.add(i);
					distancesToGoal[i] = thisDist+1;
				}
			}
		}
		
		if (dist == 0)
			System.err.print("");
		
		return dist != 0 ? dist : Integer.MAX_VALUE;
	}*/
}