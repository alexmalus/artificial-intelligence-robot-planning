package aims;

public enum Color {
	BLUE, RED, GREEN, CYAN, MAGENTA, ORANGE, PINK, YELLOW
}
