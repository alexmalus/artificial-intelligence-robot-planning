package aims;

import java.util.ArrayList;
import astar.*;
import receiver.IReceiver;
import receiver.SocketReceiver;
import receiver.StdIOReceiver;


/**
 * Class to orchestrate the solving of the level	 
 * @author kristoffer
 */
public class Coordinator {
	protected IReceiver receiver = null;
	protected Level level = null;
	public int[] realMap;
	protected ArrayList<Agent> agents;
	protected TaskDistribute distributer;

	/**
	 * <p>Will initialize the communication with the server and handling of the level map</p>
	 * 
	 * <p>On basis of the level map, it will initialize the needed agents,
	 * delegate the task assignment to the agents with help from another class</p>
	 * 
	 * <p>After task delegation the coordinator will enter a loop:</p>
	 *  <ul>
	 *  <li>Fetch plans from all agents</li>
	 *  <li>Merge all plans and check for collisions</li>
	 *  <li>If no collisions commit first action of every plan to server</li>
	 *  <li>repeat previous step until collision</li>
	 *  </ul>
     * @param netio True if we want comminication via IP sockets
	 */
    private Coordinator(boolean netio) {
        if (netio) this.receiver = new SocketReceiver(); 
        else this.receiver = new StdIOReceiver();
        
		this.level = Level.getSingletonObject();
        
		//Read the map from server
		String map = this.readMap();
		//System.err.println("Calling ParseLevel with string:\n"+map);
		//Create a level from the map string
		this.realMap = this.level.loadFromString(map);
		//Create the number of agents in this level
		this.initAgents();

		this.distributer = new TaskDistribute(this.agents, this.realMap, this.level);
	}
	
	/**
     * Start sending actions from agent plans to server,
     * and continue until we determine the map is complete or we can't solve
     * any more tasks
     */
	public void loop() {
//		String reply = "";
//		while (reply.equals(""))
//			reply = this.receiver.readLine();
		
        //Create tasks from the level
        this.distributer.createTasks();
        
		// Initially distribute the tasks
		this.distributer.assignTasks(false);
		this.distributer.moveAwayFreeAgents();
		
		// Determine if the agents initially has a plan
		boolean[] agentHadPlan = new boolean[this.agents.size()];
		for (int i = 0; i < this.agents.size(); i++) {
			agentHadPlan[i] = this.agents.get(i).hasNext();
		}
		
		while (true) { // ?? replace with while (!this.distributer.finishedMap()) {
			boolean shouldRedistribute = false;
			String send = "[";
			
			int numPlans = 0;
			
			ArrayList<Action> actions = new ArrayList<Action>();
			Map testMap = new Map(this.realMap, new Map(this.realMap, null));
            
			// Get actions from all agents
			for (int i = 0; i < this.agents.size(); i++) {
				Action a = this.agents.get(i).getNextAction();
                
                //Tryout this action
                if (a != null && !Level.applyAction(testMap, a, this.agents.get(i).position, false)) {
                    System.err.println("Action "+a+" failed for agent "+this.agents.get(i).id);
                    this.agents.get(i).releaseTask();
                    a = null;
                }
                
                
				if (agentHadPlan[i] && (a == null)) {
					shouldRedistribute = true;
				}
				if (a != null) ++numPlans;
				agentHadPlan[i] = a != null;
				actions.add(a);
				
				send += Action.toString(a);
				send += i == this.agents.size() - 1 ? "]" : ",";
			}
			
			// Are there any plans left?
			if (numPlans == 0 && !shouldRedistribute)
				break;
			
			// Send the next actions and receive a reply from the server
			this.receiver.write(send);
			String reply = this.receiver.readLine();
			if (reply == null)
				return;
			ArrayList<Boolean> status = this.parseServerReply(reply);
			
			// Iterate over the replies
			for (int i = 0; i < status.size(); i++) {
				Action a = actions.get(i);
				Agent ag = agents.get(i);
				if (status.get(i)) {
					if (a != null && a.type() != ActionType.NOOP) {
                        //Update the real map
						Level.applyAction(this.realMap, a, ag.position, false);
                        //Update the agent position
                        ag.position = Level.getPosFromPosInDirection(ag.position, a.direction());
                    }
				}
				else {
					// Handle unknown objects
                    shouldRedistribute = true;
                    System.err.println("Agent "+ag.id+" could not do: "+a);
                    int obsPos = a.getTargetPositionFromPosition(ag.position);
                    //ag.addActionToHead(a);
                    ag.releaseTask();
                    Level.addWall(this.realMap, obsPos);
                    Level.resetShortestDistances();
                    System.err.println("Added wall at "+Level.coordsToString(obsPos));
				}
			}
            
            // Should the tasks be redistributed?
			if (shouldRedistribute) {
				// Can the tasks be redistributed at all?
				this.distributer.assignTasks(false);
				this.distributer.moveAwayFreeAgents();
				//if (!this.distributer.assignTasks()) break;
			}
		}
	}
    
    public ArrayList<Boolean> parseServerReply(String reply) {
        reply = reply.replaceAll("[\\[\\]\\s]", "");
        String retvals[] = reply.split(",");
        ArrayList<Boolean> retval = new ArrayList<Boolean>();
        for (String s: retvals) {
            if (s.equals("true")) retval.add(true);
            else retval.add(false);
        }
        
        return retval;
    }
	
	/**
	 * Initialize the agent object based on the agents on the level map.
	 */
	protected void initAgents() {
		//Get the agent in the map
		ArrayList<Integer> agnts = this.level.getAgents();
		this.agents = new ArrayList<Agent>();

		for (int i=0; i<agnts.size(); i++) {
			int index = agnts.get(i);
			if (index == -1) break; //Agents numbers are coherent, we can stop now!
			int aid = Level.getAgentId(this.realMap[index]);
			Agent agn = new Agent(Level.getRowFromIndex(index),
					Level.getColumnFromIndex(index), Level.getAgentColor(aid), aid);
			this.agents.add(agn);
		}
	}
    
	/**
	 * Read the map string from the receiver input. This method will block until the full map is received
	 * @return The map string
	 */
	protected String readMap() {
		StringBuffer buf = new StringBuffer();
		String s =null;
		int EmptyStrSeen = 0;
		while ((s = this.receiver.readLine()) != null) {
			if (s.equals("")) EmptyStrSeen++;
			if (EmptyStrSeen == 2) {
				System.err.println("Level read!");
				break;
			}
			buf.append(s);
			buf.append("\n");
		}
		return buf.toString();
	}

	/**
	 * Entry point for our Agent Client
	 * @param arg
	 */
	public static void main(String arg[]){
        boolean netio = false;
        if (arg.length > 0 && arg[0].equalsIgnoreCase("-netio")) {
            netio = true;
        }
		// Start everything! This will invoke the level solving 
		Coordinator coord = new Coordinator(netio);
		coord.loop();

	}
}
