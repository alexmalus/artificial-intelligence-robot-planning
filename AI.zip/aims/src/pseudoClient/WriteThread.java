package pseudoClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

public class WriteThread extends Thread {
	protected PrintWriter out;
	protected boolean exec = true;
	protected server owner;
	protected String append;
	protected BufferedReader stdIn;
	
	WriteThread(PrintWriter output,BufferedReader in, server caller, String append) {
		this.out = output;
		this.owner = caller;
		this.append = append;
		this.stdIn = in;
	}
	
	public void run() {
		String userInput;
		
		//Append text to beginning of output socket
		this.out.print(this.append);
		this.out.flush();
		
		try {
			while ((userInput = this.stdIn.readLine()) != null && this.exec == true) {
			    this.out.println(userInput);
			}
		}
		catch (IOException e) {
			System.err.println("ERR: Could not read from stdin!");
			System.err.println(e.toString());
		}
		
		System.err.println("Socket write thread terminating");
		this.out.close();
		
		if (this.exec) this.owner.terminateConnection();
	}
	
	// Causes the thread to end execution gracefully
		public void close() {
			this.exec = false;
		}
}
