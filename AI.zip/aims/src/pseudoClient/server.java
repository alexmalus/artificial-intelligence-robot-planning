package pseudoClient;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;


public class server {

	protected int portNum;
	protected String bindAddress;
	
	protected ServerSocket serverSocket = null;
	protected Socket clientSocket = null;
	protected PrintWriter out = null;
	protected BufferedReader in = null; 
	protected ReadThread readerThread = null;
	protected WriteThread writerThread = null;
	protected boolean runThread = true;
	protected boolean connected = false;
	protected boolean listening = false;
	
	protected String mapText = "";
	protected BufferedReader stdIn;
	
	
	public server(String addr, int port) {
		super();
		this.portNum = port;
		this.bindAddress = addr;
		
//		//Record map data
		this.stdIn = new BufferedReader(
                new InputStreamReader(System.in));
		int newLinesSeen = 0;
		try {
			String line;
			System.err.println("Will read level data text...");
			while ((line = this.stdIn.readLine()) != null) {
				this.mapText += line+"\n";
				if (line.equals("")) newLinesSeen++;
				
				if (newLinesSeen >= 2) break;
			}
			System.err.println("Level text read.");
		}
		catch (IOException e) {
			System.err.println("ERR: Could not read map string from std in");
			System.err.println(e.toString());
			System.exit(1);
		}
//		try {
//			this.stdIn.mark(1024);
//		} catch (IOException e) {
//			System.err.println("ERR: Could not mark std in stream");
//			System.err.println(e.toString());
//			System.exit(1);
//		}
	}
	
	public void listen() {
		this.listening = true;
		
		while (this.listening == true) {
			
			if (this.serverSocket == null) {
				try {
					this.serverSocket = new ServerSocket(this.portNum);
		            System.err.println("AimsServer listening for connection...");
		        } catch (IOException e) {
		            System.err.println("Couldn't get open server"
		                               + " connection to: "+this.bindAddress+":"+this.portNum+"\n"+e.toString());
		            return;
		        }
			}
			
			try {
				
				
				Socket s = this.serverSocket.accept();
				System.err.println("Accepted new connection...");
				if (this.connected == true) {
					System.err.println("Reject connection attempt, server is already connected to a client!");
					s.close();
				}
				else {
					this.connected = true;
					
					this.out = new PrintWriter(s.getOutputStream(), true);
					this.in = 
					    new BufferedReader(new InputStreamReader(s.getInputStream()));
					
					//Start reader loop on new thread
					this.readerThread = new ReadThread(this.in,this);
					this.readerThread.start();
					
					//Start writer loop in new thread
					//this.stdIn.reset();
					this.writerThread = new WriteThread(this.out,this.stdIn,this,this.mapText);
					this.writerThread.start();
				}
			}
			catch (IOException e) {
				System.err.println("ERR: Could not accept incomming connection");
				System.err.println(e.toString());
			}
		}
	}
	
	public void terminateConnection() {
		this.readerThread.close();
		this.writerThread.close();
		this.connected = false;
		System.err.println("Connection closed.");
	}
	
	public void stopServer() {
		this.listening = false;
	}
	
//	public boolean bind() {
//		try {
//			this.serverSocket = new ServerSocket(this.portNum);
//            System.err.println("AimsServer listening for connection...");
//        } catch (IOException e) {
//            System.err.println("Couldn't get open server"
//                               + " connection to: "+this.bindAddress+":"+this.portNum+"\n"+e.toString());
//            return false;
//        }
//		
//		try {
//			this.clientSocket = this.serverSocket.accept();
//			System.err.println("Connection client established");
//			
//			
//			System.err.println("Closing socket");
//			this.clientSocket.close();
//			return true;
//			
//		} catch (IOException e) {
//			System.err.println("Could not accept incomming connection at port: "+this.portNum+"\n"+e.toString());
//			return false;
//		}
//		
//	}
	
//	protected void writer() throws Exception {
//		BufferedReader stdIn = new BufferedReader(
//                new InputStreamReader(System.in));
//		String userInput;
//		while ((userInput = stdIn.readLine()) != null) {
//		    this.out.println(userInput);
//		}
//		System.err.println("Socket write loop ended, killing reader thread...");
//		
//		this.out.close();
//	}
//	
//	protected void reader() throws Exception {
//		String inputLine;
//		while ((inputLine = this.in.readLine()) != null) {   
//		    System.out.println(inputLine);
//		}
//		System.err.println("Socket read loop ended");
//		this.in.close();
//	}

//	@Override
//	public void run() {
//		try {
//			this.reader();
//		} catch (Exception e) {
//			System.err.println("Error reading from socket connection:\n"+e.toString());
//			try {
//				this.clientSocket.close();
//			} catch (IOException e1) {
//				e1.printStackTrace();
//			}
//			System.exit(1);
//		}
//		
//	}
	
	/**
	 * Main method, initializes the server object 
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if (args.length > 2) {
			System.err.println("Invalid number of arguments ("+args.length+")!\nUsage: ./aimsServer host-addr [port-num]\nIf port-num is not specified, the default is 1234");
		}
		
		int port = 4321;
		String bind = "localhost";
		
		if (args.length == 1) bind = args[0];
		if (args.length == 2) {
			bind = args[0];
			port = new Integer(args[1]).intValue();
		}
		server s = new server(bind, port);
		s.listen();
		
//		if (!serverOK) {
//			System.err.println("Server encountered an error, will exit!");
//			System.exit(1);
//		}
	}
}
