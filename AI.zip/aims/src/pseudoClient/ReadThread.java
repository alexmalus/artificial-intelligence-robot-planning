package pseudoClient;

import java.io.BufferedReader;
import java.io.IOException;

public class ReadThread extends Thread {
	
	protected BufferedReader in;
	protected boolean exec = true;
	protected server owner;
	
	ReadThread(BufferedReader input, server caller) {
		this.in = input;
		this.owner = caller;
	}
	
	// Function to execute concurrently
	public void run() {
		String inputLine;
		try {
			while ((inputLine = this.in.readLine()) != null && this.exec == true) {   
			    System.out.println(inputLine);
			}
		}
		catch (IOException e) {
			System.err.println("ERR: Could read from socket input!");
		}
		
		try {
			this.in.close();
		} catch (IOException e) {
			System.err.println("ERR: Could not close socket input reader!");
		}
		
		System.err.println("Socket read thread ended");
		if (this.exec) this.owner.terminateConnection();
	}
	
	// Causes the thread to end execution gracefully
	public void close() {
		this.exec = false;
		try {
			this.in.close();
		} catch (IOException e) {
			System.err.println("ERR: read thread could not close input socket");
		}
	}
}
